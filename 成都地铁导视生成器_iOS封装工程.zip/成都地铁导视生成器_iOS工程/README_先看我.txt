成都地铁导视生成器 - iOS 封装工程
================================

当前工程做了什么
- 将你提供的完整 HTML 原样放入 MetroGuide/Resources/index.html。
- 使用 SwiftUI + WKWebView 加载本地 HTML，离线页面资源可随 App 一起打包。
- 支持 iOS 15 及以上，iPhone 设备；允许竖屏和横屏。
- 配置 GitHub Actions 的 macOS 云端构建，生成未签名 IPA。

重要说明
- 当前压缩包是 iOS 源工程，不是已签名、可直接安装的 IPA。
- 本工程在当前环境无法运行 Xcode/iOS SDK，因此没有声称已完成真实 iOS 编译或真机测试。
- GitHub Actions 会构建未签名 IPA。安装前必须用你自己的 Apple 开发者身份签名。
- 免费 Apple ID 通常可用于个人侧载，但签名有效期通常较短；付费开发者账号有不同的分发能力。
- HTML 的文件下载/导入在 WKWebView 中可能与 Safari 有差异，首次真机测试应重点检查 JSON/PNG 导入导出。

如何在 Windows 生成 IPA
1. 解压本工程 ZIP。
2. 在 GitHub 新建一个空仓库，例如 metro-guide-ios。
3. 将解压后的全部文件上传到仓库根目录（确保 .github/workflows/build-ipa.yml 也上传）。
4. 打开仓库的 Actions 页面，选择 “Build unsigned iOS IPA”，点击 Run workflow。
5. 等待任务完成，在该次运行页面底部 Artifacts 下载 MetroGuide-unsigned-IPA。
6. 解压 Artifact，得到 MetroGuide-unsigned.ipa。
7. 在 Windows 使用可信的 iOS 侧载/签名工具（例如 Sideloadly 或 AltStore 的 Windows 方案），用自己的 Apple ID 对 IPA 签名并安装到已连接的 iPhone。
8. iPhone 如提示开发者不受信任，前往“设置 > 通用 > VPN 与设备管理”信任对应开发者（菜单名称可能随 iOS 版本变化）。

GitHub Actions 注意事项
- 仓库需要启用 Actions。
- 如果组织策略禁用了 GitHub-hosted macOS runner，需要改用允许的 runner。
- 构建产物保留 14 天，请及时下载。

后续如要发布 App Store，需要改为正式签名、归档和 App Store Connect 上传流程；本工程当前不是 App Store 发布包。
